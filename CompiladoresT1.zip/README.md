# Compiladores - T1

## Integrantes

* Hugo Moraes Dzin        8532186     BCC - A
* Kaique Lupo Leite       8531907     BCC - A
* Luiz Eduardo Dorici     4165850     BCC - A

## Compilação do Analisador Léxico

Para compilar, basta executar *make* no diretório raiz deste projeto. Após a compilação, o arquivo binário se encontrará na pasta */bin*.

## Execução do Analisador Léxico

Para executar o analisador no diretório raiz, basta digitar *./bin/gcc- <caminho_do_arquivo>*. Além de realizar a executação diretamente pelo binário, é possível usar o comando *make ARGS="<caminho_do_arquivo>" run* no diretório raiz.
